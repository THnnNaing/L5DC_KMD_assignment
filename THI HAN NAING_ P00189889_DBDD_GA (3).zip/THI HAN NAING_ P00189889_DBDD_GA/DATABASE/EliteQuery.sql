 CREATE TABLE Customers (
    CustomerID VARCHAR(10)not null CHECK (CustomerID Like 'CusID-%'), PRIMARY KEY(CustomerID),
    CustomerName VARCHAR(50),
    CustomerPhoneNo VARCHAR(50),
    CustomerNRC VARCHAR(50),
    CustomerPassport VARCHAR(50),
    CustomerEmail VARCHAR(50),
    CustomerDoB DATE,
    CustomerAddress VARCHAR(255)
);

SELECT * FROM Customers;

CREATE TABLE Bookings (
    BookingID VARCHAR(10)not null CHECK (BookingID Like 'BkID-%'), PRIMARY KEY(BookingID),
    BookingDate DATE,
    TotalPeople VARCHAR(30),
    TotalCost VARCHAR(50),
    BookingStatus VARCHAR(30),
    PaymentID VARCHAR(10),
    CustomerID VARCHAR(10),
    StaffID VARCHAR(10),
    FOREIGN KEY (PaymentID) REFERENCES Payments(PaymentID),
    FOREIGN KEY (CustomerID) REFERENCES Customers(CustomerID),
    FOREIGN KEY (StaffID) REFERENCES Staffs(StaffID)
);

SELECT * FROM Bookings;

CREATE TABLE Payments (
    PaymentID VARCHAR(10)not null PRIMARY KEY,
	CHECK (PaymentID Like 'PayID-%'),
    PaymentName VARCHAR(10),
    PaymentDate DATE,
    PaymentAmount VARCHAR(50),
    PaymentStatus VARCHAR(30),
    PaymentNote VARCHAR(255),
    PaymentTypeID VARCHAR(10),
    FOREIGN KEY (PaymentTypeID) REFERENCES PaymentTypes(PaymentTypeID)
);

SELECT * FROM Payments;

CREATE TABLE PaymentTypes (
    PaymentTypeID VARCHAR(10)not null PRIMARY KEY,
	CHECK (PaymentTypeID Like 'PtID-%'),
    PaymentType VARCHAR(50),
    PaymentDescription VARCHAR(255)
);

SELECT * FROM PaymentTypes;

CREATE TABLE BookingDetails (
    BookingDetailsID VARCHAR(10)not null PRIMARY KEY,
	CHECK (BookingDetailsID Like 'BdID-%'),
    BookingID VARCHAR(10),
    PackageID VARCHAR(10),
    StartDate DATE,
    EndDate DATE,
    NumOfPeople INT,
    PackageTotalPrice INT,
    FOREIGN KEY (BookingID) REFERENCES Bookings(BookingID),
    FOREIGN KEY (PackageID) REFERENCES Packages(PackageID)
);

drop table BookingDetails;

SELECT * FROM BookingDetails;

CREATE TABLE Packages (
    PackageID VARCHAR(10)not null PRIMARY KEY,
	CHECK (PackageID Like 'PkID-%'),
    PackageName VARCHAR(150),
    PackageDescription VARCHAR(255),
    PackageUnitPrice VARCHAR(50),
    PackageDuration VARCHAR(100),
    AccommodationID VARCHAR(10),
    VehicleID VARCHAR(10),
    FOREIGN KEY (AccommodationID) REFERENCES Accommodations(AccommodationID),
    FOREIGN KEY (VehicleID) REFERENCES Vehicles(VehicleID)
);

SELECT * FROM Packages;

CREATE TABLE Accommodations (
    AccommodationID VARCHAR(10)not null PRIMARY KEY,
	CHECK (AccommodationID Like 'AcoID-%'),
    AccommodationType VARCHAR(50),
    AccommodationName VARCHAR(50),
    AccommodationDesc VARCHAR(255),
    AccommodationPrice VARCHAR(50)
);

SELECT * FROM Accommodations;

CREATE TABLE Vehicles (
    VehicleID VARCHAR(10)not null PRIMARY KEY,
	CHECK (VehicleID Like 'VeID-%'),
    VehicleType VARCHAR(50),
    VehicleDescription VARCHAR(255),
    VehiclePrice VARCHAR(50)
);

Alter Table Vehicles
Alter Column VehiclePrice int;


SELECT * FROM Vehicles;

CREATE TABLE SchedulePackages (
    SchedulePackageID VARCHAR(10)not null PRIMARY KEY,
	CHECK (SchedulePackageID Like 'SPID-%'),
    ScheduleID VARCHAR(10),
    PackageID VARCHAR(10),
    StartDate DATE,
    EndDate DATE,
    FOREIGN KEY (ScheduleID) REFERENCES Schedules(ScheduleID),
    FOREIGN KEY (PackageID) REFERENCES Packages(PackageID)
);

SELECT * FROM SchedulePackages;

CREATE TABLE Schedules (
    ScheduleID VARCHAR(10)not null PRIMARY KEY,
	CHECK (ScheduleID Like 'ScID-%'),
    DepartureDate DATE,
    ReturnDate DATE,
    TotalPackage VARCHAR(10),
    StaffID VARCHAR(10),
    ReviewID VARCHAR(10),
    ServiceID VARCHAR(10),
    FOREIGN KEY (StaffID) REFERENCES Staffs(StaffID),
    FOREIGN KEY (ReviewID) REFERENCES Reviews(ReviewID),
    FOREIGN KEY (ServiceID) REFERENCES Services(ServiceID)
);

SELECT * FROM Schedules;

CREATE TABLE Staffs (
    StaffID VARCHAR(10)not null PRIMARY KEY,
	CHECK (StaffID Like 'SID-%'),
    StaffName VARCHAR(30),
    StaffDoB DATE,
    StaffPhoneNumber VARCHAR(30),
    StaffEmail VARCHAR(30),
    StaffGender VARCHAR(1) CHECK (StaffGender IN ('M', 'F')),
    StaffRoleID VARCHAR(10),
    FOREIGN KEY (StaffRoleID) REFERENCES StaffRoles(StaffRoleID)
);

SELECT * FROM Staffs;

CREATE TABLE StaffRoles (
    StaffRoleID VARCHAR(10)not null PRIMARY KEY,
	CHECK (StaffRoleID Like 'SrID-%'),
    StaffRole VARCHAR(30),
    StaffDescription VARCHAR(255),
    Qualifications VARCHAR(255),
    Salary VARCHAR(50),
    Experiences VARCHAR(255)
);

SELECT * FROM StaffRoles;

CREATE TABLE Reviews (
    ReviewID VARCHAR(10)not null PRIMARY KEY,
	CHECK (ReviewID Like 'RID-%'),
    Review VARCHAR(255),
    ReviewDate DATE,
    Rating VARCHAR(10),
    CustomerID VARCHAR(10),
    FOREIGN KEY (CustomerID) REFERENCES Customers(CustomerID)
);

SELECT * FROM Reviews;

CREATE TABLE ReviewSchedules (
    ReviewScheduleID VARCHAR(10)not null PRIMARY KEY,
	CHECK (ReviewScheduleID Like 'RSID-%'),
	ScheduleID VARCHAR(10),
    ReviewID VARCHAR(10),
    ReviewQty INT,
    ServiceID VARCHAR(10),
    NumOfPeople VARCHAR(50),
    ServiceQty INT,
	FOREIGN KEY (ScheduleID) REFERENCES Schedules(ScheduleID),
    FOREIGN KEY (ReviewID) REFERENCES Reviews(ReviewID),
    FOREIGN KEY (ServiceID) REFERENCES Services(ServiceID)
);

Drop Table ReviewSchedules;

SELECT * FROM ReviewSchedules;

CREATE TABLE Services (
    ServiceID VARCHAR(10)not null PRIMARY KEY,
	CHECK (ServiceID Like 'SerID-%'),
    Service VARCHAR(255),
    ServiceDescription VARCHAR(255),
    ReviewID VARCHAR(10),
    FOREIGN KEY (ReviewID) REFERENCES Reviews(ReviewID)
);

SELECT * FROM Services;

/*INSERT QURIES*/
/*FOR CUSTOMER*/
INSERT INTO Customers (CustomerID,CustomerName,CustomerPhoneNo,CustomerNRC,CustomerPassport,CustomerEmail,CustomerDoB,CustomerAddress)
VALUES 
	('CusID-001', 'Aung Myat', '+95 9 1234 56789', '12/MaNaTa(N)123456', 'MP-001-234567', 'aung.myat@email.com', '1990-03-15', 'Yangon, Myanmar'),
    ('CusID-002', 'May Lin', '+95 9 8765 43210', '21/MaMaLa(N)654321', 'MP-002-345678', 'may.lin@email.com', '1985-07-22', 'Mandalay, Myanmar'),
    ('CusID-003', 'Thiri Win', '+95 9 2345 67890', '33/NaNaPa(N)987654', 'MP-003-456789', 'thiri.win@email.com', '1992-11-05', 'Naypyidaw, Myanmar'),
    ('CusID-004', 'Zaw Htet', '+95 9 5555 1234', '45/NaNaPa(N)876543', 'MP-004-567890', 'zaw.htet@email.com', '1988-09-18', 'Bagan, Myanmar'),
    ('CusID-005', 'Su Myat', '+95 9 9876 54321', '53/MaMaLa(N)765432', 'MP-005-678901', 'su.myat@email.com', '1995-12-12', 'Inle Lake, Myanmar'),
    ('CusID-006', 'Kyaw Zin', '+95 9 2345 6789', '67/MaMaLa(N)654321', 'MP-006-789012', 'kyaw.zin@email.com', '1982-08-05', 'Mawlamyine, Myanmar'),
    ('CusID-007', 'Hnin Thazin', '+95 9 8765 4321', '78/NaNaPa(N)543210', 'MP-007-890123', 'hnin.thazin@email.com', '1998-04-30', 'Ngapali Beach, Myanmar'),
    ('CusID-008', 'Tun Naing', '+95 9 1111 2222', '89/MaNaTa(N)432109', 'MP-008-901234', 'tun.naing@email.com', '1980-02-14', 'Pyin Oo Lwin, Myanmar'),
    ('CusID-009', 'Yin Min', '+95 9 3333 4444', '92/NaNaPa(N)321098', 'MP-009-012345', 'yin.min@email.com', '1996-06-22', 'Bagan, Myanmar'),
    ('CusID-010', 'Thida Htwe', '+95 9 5555 6666', '10/MaMaLa(N)210987', 'MP-010-123456', 'thida.htwe@email.com', '1987-09-09', 'Mandalay, Myanmar');

	SELECT * FROM Customers;

/*=======================================================================================================================*/
/*FOR PAYMENT TYPES*/
INSERT INTO PaymentTypes (PaymentTypeID, PaymentType, PaymentDescription)
VALUES ('PtID-001', 'Credit Card', 'Payment made using a credit card'),
		('PtID-002', 'Debit Card', 'Payment made using a debit card'),
		('PtID-003', 'Bank Transfer', 'Payment made through bank transfer'),
		('PtID-004', 'Cash', 'Payment made in cash at the office'),
		('PtID-005', 'Cash on Delivery', 'Payment can be done when arrival on delivery of voucher'),
		('PtID-006', 'Mobile Wallet', 'Payment made using a mobile wallet'),
		('PtID-007', 'Cheque', 'Payment made by cheque'),
		('PtID-008', 'Travel Voucher', 'Payment made using a travel voucher'),
		('PtID-009', 'Cryptocurrency', 'Payment made using cryptocurrency'),
		('PtID-010', 'Online Transfer', 'Payment made through online services');

		SELECT * FROM PaymentTypes;

/*=======================================================================================================================*/
/*FOR PAYMENTS NEED TO CHANGE PAYMENT AMOUNTS*/
INSERT INTO Payments (PaymentID, PaymentName, PaymentDate, PaymentAmount, PaymentStatus, PaymentNote, PaymentTypeID)
VALUES ('PayID-001', 'UAB', '2023-11-01', '11070', 'Completed', 'Booking deposit for tour package', 'PtID-001'),
       ('PayID-002', 'KBZ', '2023-11-01', '7060', 'Pending', 'Final payment for upcoming tour', 'PtID-003'),
       ('PayID-003', 'In Person', '2023-11-01', '2050', 'Completed', 'Payment for additional tour services', 'PtID-004'),
       ('PayID-004', 'In Person', '2023-11-05', '4710', 'Cancelled', 'Cancellation fee for tour booking', 'PtID-004'),
       ('PayID-005', 'AYApay', '2023-11-07', '7900', 'Completed', 'Advance payment for future tour', 'PtID-006'),
       ('PayID-006', 'Kpay', '2023-11-19', '2700', 'Completed', 'Necessary payments for upcoming tour', 'PtID-006'),
       ('PayID-007', 'ChequePay', '2023-12-05', '5400', 'Completed', 'Payment for tour packages', 'PtID-007'),
       ('PayID-008', 'Wave Money', '2023-12-06', '21120', 'Pending', 'Payment for travel insurance coverage', 'PtID-010'),
       ('PayID-009', 'In Person', '2023-12-07', '4440', 'Completed', 'Payment for VIP tour package', 'PtID-004'),
       ('PayID-010', 'Wave Pay', '2023-12-01', '14200', 'Completed', 'Online Payment for bookings', 'PtID-010');

	   SELECT * FROM Payments;

/*=======================================================================================================================*/
/*FOR ACCOMMODATIONS*/
INSERT INTO Accommodations (AccommodationID, AccommodationType, AccommodationName, AccommodationDesc, AccommodationPrice)
VALUES ('AcoID-001', 'Hotel', 'Shangri-La Hotel', 'Luxurious 5-star hotel', '200'),
		('AcoID-002', 'Resort', 'Ngapali Bay Villas & Spa', 'Secluded beachfront resort', '400'),
		('AcoID-003', 'Guesthouse', 'Golden Guest Inn', 'Charming guesthouse ', '50'),
		('AcoID-004', 'Mountain Lodge', 'Inle View Resort & Spa', 'Scenic mountain lodge overlooking', '250'),
		('AcoID-005', 'Floating Hotel', 'Amara Ocean Resort', 'Unique floating hotel', '400'),
		('AcoID-006', 'Boutique Hotel', 'The Loft', 'Trendy boutique hotel', '200'),
		('AcoID-007', 'Eco Lodge', 'Green Valley Eco Resort', 'Environmentally friendly eco lodge ', '150'),
		('AcoID-008', 'Heritage Inn', 'Thiripyitsaya Sanctuary Resort', 'Heritage inn surrounded by ancient pagodas', '300'),
		('AcoID-009', 'Beachfront Villa', 'Aureum Palace Hotel & Resort', 'Luxurious beachfront villas', '400'),
		('AcoID-010', 'Riverside Retreat', 'The Hotel by the Red Canal', 'Tranquil riverside retreat', '150');

		SELECT * FROM Accommodations;

/*================================================================================================================================================*/
/*FOR VEHICLES*/
INSERT INTO Vehicles (VehicleID, VehicleType, VehicleDescription, VehiclePrice)
VALUES ('VeID-001', 'Sedan', 'Comfortable sedan for city tours', '50'),
		('VeID-002', 'SUV', 'Spacious SUV for family trips', '80'),
		('VeID-003', 'Minivan', 'Minivan for group transportation', '100'),
		('VeID-004', 'Luxury Car', 'Luxurious car for VIP transport', '200'),
		('VeID-005', 'Motorcycle', 'Motorcycle for adventurous tours', '50'),
		('VeID-006', 'Train', 'Train for comfort travelling', '10'),
		('VeID-007', 'Bus', 'Bus for travelling with lots of unkown people', '30'),
		('VeID-008', 'Plane', 'Plane for faster travelling', '150'),
		('VeID-009', 'Jeep', 'Off-road Jeep for adventure tours', '70'),
		('VeID-010', 'Boat', 'Boat for ocean viewing tours', '50');

		SELECT * FROM Vehicles;

/*=======================================================================================================================*/
/*FOR PACKAGES CHANGE PROPER ONE PLEASE*/
INSERT INTO Packages (PackageID, PackageName, PackageDescription, PackageUnitPrice, PackageDuration, AccommodationID, VehicleID)
VALUES ('PkID-001', 'Golden Pagoda Explorer', 'Explore Myanmar ancient pagodas and cultural sites', '3000', '10 days', 'AcoID-001', 'VeID-007'),
		('PkID-002', 'Majestic Inle Lake Retreat', 'Relax and unwind with a scenic retreat at Inle Lake', '1800', '2 days', 'AcoID-003', 'VeID-010'),
		('PkID-003', 'Beach Bliss in Ngapali', 'Enjoy sun, sand and sea at Ngapali pristine beaches', '1500', '3 days', 'AcoID-002','VeID-008'),
		('PkID-004', 'Bagan Balloon Adventure', 'Experience a magical hot air balloon ride over Bagan', '2000', '3 days', 'AcoID-006', 'VeID-003'),
		('PkID-005', 'Cultural Gems of Mandalay', 'Immerse yourself in Mandalay rich cultural heritage', '1400', '2 days', 'AcoID-001', 'VeID-007'),
		('PkID-006', 'Yangon City Escape', 'Discover the vibrant city life of Yangon', '1000', '2 days', 'AcoID-002', 'VeID-002'),
		('PkID-007', 'Riverside Rendezvous in Hpa-An', 'Experience the scenic beauty of Hpa-An by the river', '1600', '2 days', 'AcoID-010', 'VeID-010'),
		('PkID-008', 'Adventure Safari in Rakhine', 'Embark on an exciting safari adventure in Rakhine', '2000', '3 days', 'AcoID-007', 'VeID-009'),
		('PkID-009', 'Hill Station Retreat in Pyin Oo Lwin', 'Escape to the cool hills of Pyin Oo Lwin', '1000', '2 days', 'AcoID-007', 'VeID-004'),
		('PkID-010', 'Luxury Cruise on the Irrawaddy', 'Sail in style along the majestic Irrawaddy River', '3000', '3 days', 'AcoID-009', 'VeID-008');

		SELECT * FROM Packages;

/*=========================================================================================================================================================*/
/* FOR BOOKINGS */
INSERT INTO Bookings (BookingID, BookingDate, TotalPeople, TotalCost, BookingStatus, PaymentID, CustomerID, StaffID)
VALUES ('BkID-001', '2023-11-01', '3', '11070', 'Confirmed', 'PayID-001', 'CusID-001', 'SID-001'),
		('BkID-002', '2023-11-01', '2', '7060', 'Pending', 'PayID-002', 'CusID-002', 'SID-002'),
		('BkID-003', '2023-11-01', '1', '2050', 'Confirmed', 'PayID-003', 'CusID-003', 'SID-003'),
		('BkID-004', '2023-11-05', '1', '4710', 'Confirmed', 'PayID-004', 'CusID-004', 'SID-004'),
		('BkID-005', '2023-11-07', '2', '7900', 'Pending', 'PayID-005', 'CusID-005', 'SID-005'),
		('BkID-006', '2023-11-19', '2', '2700', 'Confirmed', 'PayID-006', 'CusID-006', 'SID-006'),
		('BkID-007', '2023-12-05', '3', '5400', 'Pending', 'PayID-007', 'CusID-007', 'SID-007'),
		('BkID-008', '2023-12-06', '4', '21120', 'Confirmed', 'PayID-008', 'CusID-008', 'SID-008'),
		('BkID-009', '2023-12-07', '2', '4440', 'Pending', 'PayID-009', 'CusID-009', 'SID-009'),
		('BkID-010', '2023-12-01', '4', '14200', 'Confirmed', 'PayID-010', 'CusID-010', 'SID-010');

		SELECT * FROM Bookings;

/*=========================================================================================================================================================*/
/*FOR BOOKING DETAILS NEED TO CHANGE DATES*/
INSERT INTO BookingDetails (BookingDetailsID, BookingID, PackageID, StartDate, EndDate, NumOfPeople, PackageTotalPrice)
VALUES ('BdID-001', 'BkID-001', 'PkID-004', '2023-12-01', '2023-12-03', 3, 2060),
		('BdID-002', 'BkID-001', 'PkID-005', '2023-12-04', '2023-12-05', 3, 1630),
		('BdID-003', 'BkID-003', 'PkID-003', '2023-12-03', '2023-12-05', 1, 2050),
		('BdID-004', 'BkID-002', 'PkID-002', '2023-12-06', '2023-12-07', 2, 1900),
		('BdID-005', 'BkID-002', 'PkID-005', '2023-12-04', '2023-12-05', 2, 1630),
		('BdID-006', 'BkID-004', 'PkID-001', '2023-12-10', '2023-12-13', 1, 3230),
		('BdID-007', 'BkID-004', 'PkID-006', '2023-12-14', '2023-12-15', 1, 1480),
		('BdID-008', 'BkID-005', 'PkID-002', '2023-12-30', '2023-12-31', 2, 1900),
		('BdID-009', 'BkID-005', 'PkID-003', '2024-01-01', '2024-01-03', 2, 2050),
		('BdID-010', 'BkID-010', 'PkID-010', '2024-01-01', '2024-01-03', 4, 3550),
		('BdID-011', 'BkID-010', 'PkID-007', '2024-01-04', '2024-01-05', 4, 1800),
		('BdID-012', 'BkID-009', 'PkID-008', '2024-01-01', '2024-01-03', 2, 2220),
		('BdID-013', 'BkID-006', 'PkID-009', '2024-01-01', '2024-01-02', 2, 1350),
		('BdID-014', 'BkID-007', 'PkID-007', '2024-01-01', '2024-01-02', 3, 1800),
		('BdID-015', 'BkID-008', 'PkID-001', '2024-01-01', '2024-01-10', 4, 3230),
		('BdID-016', 'BkID-008', 'PkID-003', '2024-01-11', '2024-01-13', 4, 2050);

		SELECT * FROM BookingDetails;

/*=======================================================================================================================*/
/*FOR STAFF ROLES*/
INSERT INTO StaffRoles (StaffRoleID, StaffRole, StaffDescription, Qualifications, Salary, Experiences)
VALUES ('SrID-001', 'Tour Guide', 'Guides tourists during travel excursions', 'Bachelor degree in Tourism', '300', '3 years in tourism industry'),
		('SrID-002', 'Driver', 'Responsible for driving and maintaining vehicles', 'Valid driver license', '120', '5 years of driving experience'),
		('SrID-003', 'Front Desk Officer', 'Handles customer inquiries and reservations', 'Diploma in Hospitality', '150', '2 years in customer service'),
		('SrID-004', 'Chef', 'Cooks meals for travelers', 'Experience in international cuisines', '250', '3 years in culinary arts'),
		('SrID-005', 'Housekeeping Staff', 'Ensures cleanliness of accommodations', 'Attention to detail', '100', '1 year in housekeeping'),
		('SrID-006', 'Travel Consultant', 'Assists customers their travel itineraries', 'Bachelor degree in Travel and Tourism', '250', '3 years in travel consultancy'),
		('SrID-007', 'Event Coordinator', 'Organizes events for the agency', 'Degree in Event Management', '200', '3 years in event coordination'),
		('SrID-008', 'IT Support Specialist', 'Solve and maintains IT-systems', 'Bachelor degree in IT,', '500', '4 years in IT support'),
		('SrID-009', 'Accountant', 'Manages financial transactions and accounts', 'Degree in Accounting', '250', '2 years in accounting'),
		('SrID-010', 'Marketing Specialist', 'Develops and implements marketing strategies', 'Degree in Marketing', '250', '2 years in marketing');

		SELECT * FROM StaffRoles;

/*=========================================================================================================================================================*/
/*FOR STAFFS*/
INSERT INTO Staffs (StaffID, StaffName, StaffDoB, StaffPhoneNumber, StaffEmail, StaffGender, StaffRoleID)
VALUES ('SID-001', 'John Smith', '1985-04-15', '+95 9 1234 56789', 'john.smith@email.com', 'M', 'SrID-001'),
		('SID-002', 'Alice Johnson', '1990-07-22', '+95 9 8765 43210', 'alice.johnson@email.com', 'F', 'SrID-002'),
		('SID-003', 'Robert Davis', '1988-11-05', '+95 5 5512 34567', 'robert.davis@email.com', 'M', 'SrID-003'),
		('SID-004', 'Emily Taylor', '1992-09-18', '+95 2 2233 4444', 'emily.taylor@email.com', 'F', 'SrID-004'),
		('SID-005', 'David Brown', '1980-07-12', '+95 6 6677 8888', 'david.brown@email.com', 'M', 'SrID-005'),
		('SID-006', 'Sophia Hernandez', '1988-12-05', '+95 1 1122 3333', 'sophia.hernandez@email.com', 'F', 'SrID-006'),
		('SID-007', 'Michael Davis', '1972-04-30', '+95 9 9988 7777', 'michael.davis@email.com', 'M', 'SrID-007'),
		('SID-008', 'Olivia Anderson', '1983-02-14', '+95 7 7766 5555', 'olivia.anderson@email.com', 'F', 'SrID-008'),
		('SID-009', 'Matthew Miller', '1997-06-22', '+95 4 4455 6666', 'matthew.miller@email.com', 'M', 'SrID-009'),
		('SID-010', 'Lily White', '1986-09-09', '+95 9 8899 0000', 'lily.white@email.com', 'F', 'SrID-010');

		SELECT * FROM Staffs; 

/*=======================================================================================================================*/
/*FOR REVIEWS*/
INSERT INTO Reviews (ReviewID, Review, ReviewDate, Rating, CustomerID)
VALUES ('RID-001', 'Great experience with the tour package! Friendly staff and amazing destinations.', '2023-05-10', '5', 'CusID-001'),
		('RID-002', 'The accommodation was fantastic, and the tour guide was very knowledgeable.', '2023-06-18', '4', 'CusID-002'),
		('RID-003', 'Had a wonderful time exploring Myanmar. Highly recommend the travel agency!', '2023-07-05', '5', 'CusID-003'),
		('RID-004', 'The tour was well-organized, and the staff went above and beyond to make our trip memorable.', '2023-08-11', '5', 'CusID-004'),
		('RID-005', 'Excellent service from booking to the end of the trip. Will definitely use this agency again!', '2023-09-07', '5', 'CusID-005'),
		('RID-006', 'The travel consultant was very helpful in creating a customized itinerary for us.', '2023-10-14', '4', 'CusID-006'),
		('RID-007', 'Loved the cultural experiences and the diverse range of activities in the tour package.', '2023-11-22', '5', 'CusID-007'),
		('RID-008', 'The accommodations were comfortable, and the transportation was smooth.', '2023-12-10', '4', 'CusID-008'),
		('RID-009', 'Impressed with the professionalism of the tour guide. Learned a lot about the local culture.', '2024-01-17', '5', 'CusID-009'),
		('RID-010', 'Had a fantastic time with the family. The package was suitable for all ages.', '2024-02-25', '5', 'CusID-010');

		SELECT * FROM Reviews;

/*=======================================================================================================================*/
/*FOR SERVICES*/
INSERT INTO Services (ServiceID, Service, ServiceDescription, ReviewID)
VALUES ('SerID-001', 'Guided Tours', 'Explore Myanmar with knowledgeable and friendly tour guides.', 'RID-001'),
		('SerID-002', 'Accommodation Booking', 'Book comfortable and well-reviewed accommodations for your stay.', 'RID-002'),
		('SerID-003', 'Customized Itineraries', 'Create personalized travel itineraries tailored to your preferences.', 'RID-006'),
		('SerID-004', 'Transportation Services', 'Arrange reliable transportation for a smooth and comfortable journey.', 'RID-004'),
		('SerID-005', 'Event Planning', 'Organize special events and activities during your travel.', 'RID-007'),
		('SerID-006', 'Cultural Experiences', 'Immerse yourself in the rich culture and traditions of Myanmar.', 'RID-009'),
		('SerID-007', 'Customer Support', 'Receive prompt and helpful assistance throughout your journey.', 'RID-005'),
		('SerID-008', 'Adventure Packages', 'Choose from a variety of adventurous tour packages.', 'RID-010'),
		('SerID-009', 'Family-Friendly Tours', 'Enjoy family-friendly activities and tours suitable for all ages.', 'RID-008'),
		('SerID-010', 'Luxury Travel Options', 'Experience luxury travel with premium accommodations and services.', 'RID-003');

		SELECT * FROM Services;

/*=======================================================================================================================*/
/*FOR SCHEDULES*/
INSERT INTO Schedules (ScheduleID, DepartureDate, ReturnDate, TotalPackage, StaffID, ReviewID, ServiceID)
VALUES ('ScID-001', '2023-11-01', '2023-11-20', '10', 'SID-001', 'RID-001', 'SerID-001'),
		('ScID-002', '2023-11-21', '2023-11-30', '10', 'SID-002', 'RID-002', 'SerID-002'),
		('ScID-003', '2023-12-01', '2023-12-07', '10', 'SID-003', 'RID-003', 'SerID-003'),
		('ScID-004', '2023-12-08', '2023-12-15', '10', 'SID-004', 'RID-004', 'SerID-004'),
		('ScID-005', '2023-12-16', '2023-12-23', '10', 'SID-005', 'RID-005', 'SerID-005'),
		('ScID-006', '2023-12-24', '2023-12-31', '10', 'SID-006', 'RID-006', 'SerID-006'),
		('ScID-007', '2023-01-01', '2023-01-05', '10', 'SID-007', 'RID-007', 'SerID-007'),
		('ScID-008', '2023-01-06', '2023-01-14', '12', 'SID-008', 'RID-008', 'SerID-008'),
		('ScID-009', '2024-01-15', '2024-01-20', '12', 'SID-009', 'RID-009', 'SerID-009'),
		('ScID-010', '2024-01-21', '2024-01-27', '12', 'SID-010', 'RID-010', 'SerID-010');

		SELECT * FROM Schedules;

/*=======================================================================================================================*/
/*FOR SCHEDULE PACKAGES  DANGER!!!*/
INSERT INTO SchedulePackages (SchedulePackageID, ScheduleID, PackageID, StartDate, EndDate)
VALUES ('SPID-001', 'ScID-001', 'PkID-001', '2023-11-01', '2023-11-10'),
		('SPID-002', 'ScID-001', 'PkID-002', '2023-11-15', '2023-11-16'),
		('SPID-003', 'ScID-003', 'PkID-003', '2023-12-03', '2023-12-06'),
		('SPID-004', 'ScID-003', 'PkID-004', '2023-12-01', '2023-12-03'),
		('SPID-005', 'ScID-003', 'PkID-005', '2023-12-04', '2023-12-05'),
		('SPID-006', 'ScID-004', 'PkID-006', '2023-12-14', '2023-12-15'),
		('SPID-007', 'ScID-007', 'PkID-007', '2023-01-04', '2023-01-05'),
		('SPID-008', 'ScID-007', 'PkID-008', '2023-01-01', '2023-01-03'),
		('SPID-009', 'ScID-007', 'PkID-009', '2024-01-01', '2024-01-02'),
		('SPID-010', 'ScID-007', 'PkID-010', '2024-01-01', '2024-01-03'),
		('SPID-011', 'ScID-009', 'PkID-002', '2024-01-15', '2024-01-16'),
		('SPID-012', 'ScID-009', 'PkID-003', '2024-01-15', '2024-01-17'),
		('SPID-013', 'ScID-010', 'PkID-004', '2024-01-25', '2024-01-27'),
		('SPID-014', 'ScID-002', 'PkID-007', '2024-11-22', '2024-11-23'),
		('SPID-015', 'ScID-006', 'PkID-002', '2024-12-30', '2024-12-31'),
		('SPID-016', 'ScID-009', 'PkID-003', '2024-01-15', '2024-01-17'),
		('SPID-017', 'ScID-008', 'PkID-003', '2024-01-11', '2024-01-13');

SELECT * FROM SchedulePackages;

/*=======================================================================================================================*/
/*FOR REVIEW Schedules*/
INSERT INTO ReviewSchedules (ReviewScheduleID, ScheduleID, ReviewID, ReviewQty, ServiceID, NumOfPeople, ServiceQty)
VALUES ('RSID-001', 'ScID-001', 'RID-001', 3, 'SerID-001', '2', 1),
		('RSID-002', 'ScID-002', 'RID-002', 6, 'SerID-002', '2', 1),
		('RSID-003', 'ScID-003', 'RID-003', 4, 'SerID-003', '4', 1),
		('RSID-004', 'ScID-004', 'RID-004', 6, 'SerID-004', '2', 1),
		('RSID-005', 'ScID-005', 'RID-005', 3, 'SerID-005', '3', 1),
		('RSID-006', 'ScID-006', 'RID-006', 2, 'SerID-006', '2', 1),
		('RSID-007', 'ScID-007', 'RID-007', 5, 'SerID-007', '5', 1),
		('RSID-008', 'ScID-008', 'RID-008', 4, 'SerID-008', '4', 1),
		('RSID-009', 'ScID-009', 'RID-009', 2, 'SerID-009', '2', 1),
		('RSID-010', 'ScID-010', 'RID-010', 4, 'SerID-010', '4', 1),
		('RSID-011', 'ScID-001', 'RID-001', 3, 'SerID-002', '2', 1),
		('RSID-012', 'ScID-001', 'RID-002', 3, 'SerID-006', '2', 1),
		('RSID-013', 'ScID-003', 'RID-004', 2, 'SerID-009', '4', 1);

		SELECT * FROM ReviewSchedules;

/*=======================================================================================================================*/
Update StaffRoles
Set Salary = 550
Where StaffRoleID = 'SrID-008';

/*=======================================================================================================================*/
SELECT c.CustomerName, bd.PackageTotalPrice, p.PackageName
FROM BookingDetails bd, Bookings b, Packages p, Customers c
WHERE bd.BookingID=b.BookingID
AND	p.PackageID=bd.PackageID
AND c.CustomerID=b.CustomerID
ORDER BY bd.PackageTotalPrice ASC;

SELECT  p.PackageName, bd.StartDate, bd.EndDate
FROM BookingDetails bd, Bookings b, Packages p
WHERE bd.BookingID=b.BookingID
AND p.PackageID=bd.PackageID
And b.BookingDate between '2023-11-01' and '2023-12-31';

SELECT b.BookingDate, c.CustomerName, p.PackageName
FROM BookingDetails bd, Bookings b, Packages p, Customers c
WHERE bd.BookingID=b.BookingID
AND p.PackageID=bd.PackageID
AND b.CustomerID=c.CustomerID
And b.BookingDate between '2023-11-01' and '2024-01-31';

SELECT  p.PackageName,
b.TotalPeople * bd.PackageTotalPrice AS package_income
FROM BookingDetails bd, Bookings b, Packages p
Where bd.BookingID= b.BookingID
AND p.PackageID = bd.PackageID;

SELECT  p.PackageName, 
COUNT (c.CustomerName) As TotalCustomer
FROM BookingDetails bd, Bookings b, Packages p, Customers c
Where bd.BookingID= b.BookingID
AND c.CustomerID=b.CustomerID
AND p.PackageID = bd.PackageID
Group By p.PackageName;

SELECT  b.BookingID,
SUM(b.TotalPeople * bd.PackageTotalPrice) As total_income
FROM BookingDetails bd, Bookings b, Packages p
Where bd.BookingID= b.BookingID
AND p.PackageID = bd.PackageID
Group By b.BookingID;

SELECT p.PackageName,a.AccommodationName,v.VehicleType
FROM  Accommodations a, Vehicles v, Packages p
Where p.AccommodationID=a.AccommodationID
AND p.VehicleID = v.VehicleID;

SELECT s.ScheduleID,
COUNT (r.Review) as totalreview
FROM Reviews r, Schedules s, ReviewSchedules rs
WHERE r.ReviewID=rs.ReviewID
AND s.ScheduleID= rs.ScheduleID
Group By s.ScheduleID;

SELECT se.Service,
COUNT (rs.ReviewQty) as TotalReview 
FROM Reviews r, Schedules s, ReviewSchedules rs, Services se
WHERE r.ReviewID=rs.ReviewID
AND s.ScheduleID= rs.ScheduleID
AND se.ServiceID=rs.ServiceID
Group By se.Service;

SELECT c.CustomerName,
Max (rs.ReviewQty) as totalreview
FROM Reviews r, Schedules s, ReviewSchedules rs, Customers c
WHERE r.ReviewID=rs.ReviewID
AND c.CustomerID= r.CustomerID
AND s.ScheduleID= rs.ScheduleID
Group By c.CustomerName;






