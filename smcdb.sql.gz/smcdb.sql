-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 29, 2024 at 12:20 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `smcdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `adminstb`
--

CREATE TABLE `adminstb` (
  `AdminID` int(11) NOT NULL,
  `AdminName` varchar(30) DEFAULT NULL,
  `AdminDateOfBirth` varchar(100) DEFAULT NULL,
  `AdminEmail` varchar(40) DEFAULT NULL,
  `AdminPassword` varchar(30) DEFAULT NULL,
  `AdminPhoneNumber` varchar(30) DEFAULT NULL,
  `AdminAddress` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `adminstb`
--

INSERT INTO `adminstb` (`AdminID`, `AdminName`, `AdminDateOfBirth`, `AdminEmail`, `AdminPassword`, `AdminPhoneNumber`, `AdminAddress`) VALUES
(1, 'Thi Han', '12.12.2000', 'thihannaing123@gmail.com', 'KMDkmd123!@#', '09436242424', '-098ugdshbknjmlc');

-- --------------------------------------------------------

--
-- Table structure for table `campaignstb`
--

CREATE TABLE `campaignstb` (
  `CampaignID` int(11) NOT NULL,
  `CampaignTitle` varchar(30) DEFAULT NULL,
  `CampaignStatus` varchar(255) DEFAULT NULL,
  `CampaignDescription` varchar(255) DEFAULT NULL,
  `SocialMediaID` int(11) DEFAULT NULL,
  `CampaignImage1` varchar(255) DEFAULT NULL,
  `CampaignImage2` varchar(255) DEFAULT NULL,
  `CampaignImage3` varchar(255) DEFAULT NULL,
  `CampaignTypeID` int(11) DEFAULT NULL,
  `StartDate` varchar(30) DEFAULT NULL,
  `EndDate` varchar(30) DEFAULT NULL,
  `Fees` int(11) DEFAULT NULL,
  `Aim` varchar(255) DEFAULT NULL,
  `Target` varchar(255) DEFAULT NULL,
  `Vision` varchar(255) DEFAULT NULL,
  `Map` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `campaignstb`
--

INSERT INTO `campaignstb` (`CampaignID`, `CampaignTitle`, `CampaignStatus`, `CampaignDescription`, `SocialMediaID`, `CampaignImage1`, `CampaignImage2`, `CampaignImage3`, `CampaignTypeID`, `StartDate`, `EndDate`, `Fees`, `Aim`, `Target`, `Vision`, `Map`) VALUES
(1, 'Drawing Campaign', 'Available', 'ABCd draw a picture', 1, '../Addimg/659bdc0963010_download.png', '../Addimg/659bdc0963417_end-to-end.asp-final-e4a3d2098efc40589fa9f87aa64a19dc.png', '../Addimg/659bdc09636e7_end-to-end-encryption-1024x550.png', 1, '2024-01-02', '2024-01-03', 5000, 'visualized to learn quick', 'both', 'To help parents and child know more about those securities ', 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3820.021437501308!2d96.15927841099281!3d16.775609020073723!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x30c1ed9d9e43cb6f%3A0x4cba3c904bddefc0!2sKMD%20Mobile%20%26%20IT%20Sales%20%26%20Service%20Center%20(Pansodan)!5e0!3m2!1sen!2smm!4v1699686009326!5m2!1sen!2smm'),
(3, 'Picture Creatives', 'Available', 'Brainstorming the staying safe ideas using pictures ', 1, '../Addimg/659e946ce7272_background.png', '../Addimg/659e946ce759b_marketing-campaign.jpg', '../Addimg/659e946ce7716_3dcampaign.jpg', 1, '2024-01-04', '2024-01-05', 5000, 'To have more idea to stay safe online', 'teenagers', 'Helping the teenagers about staying safe ideas and help their lifestyle improved.', 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3820.0214375013143!2d96.15927841094357!3d16.775609020073844!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x30c1ed9d9e43cb6f%3A0x4cba3c904bddefc0!2sKMD%20Mobile%20%26%20IT%20Sales%20%26%20Service%20Center%20(Pansodan)!5e0!3m2!1sen!2smm!4v1702801792556!5m2!1sen!2smm\" width=\"600\" height=\"450\" style=\"border:0;');

-- --------------------------------------------------------

--
-- Table structure for table `campaigntypestb`
--

CREATE TABLE `campaigntypestb` (
  `CampaignTypeID` int(11) NOT NULL,
  `CampaignTypeName` varchar(30) DEFAULT NULL,
  `CampaignTypeDescription` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `campaigntypestb`
--

INSERT INTO `campaigntypestb` (`CampaignTypeID`, `CampaignTypeName`, `CampaignTypeDescription`) VALUES
(1, 'FamilyCyberTalk', 'we will talk about cyber security for your children'),
(2, 'Online Passwords', 'This will talk about how to keep your accounts safely'),
(3, 'SafetyFirst Campaign', 'How to stay safe as a teenager. '),
(4, 'Anti-virus type', 'way to safe your devices from virus');

-- --------------------------------------------------------

--
-- Table structure for table `contactustb`
--

CREATE TABLE `contactustb` (
  `ContactusID` int(11) NOT NULL,
  `ContactDate` varchar(30) DEFAULT NULL,
  `Subject` varchar(50) DEFAULT NULL,
  `ContactMessage` varchar(255) DEFAULT NULL,
  `CustomerID` int(11) DEFAULT NULL,
  `Status` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `contactustb`
--

INSERT INTO `contactustb` (`ContactusID`, `ContactDate`, `Subject`, `ContactMessage`, `CustomerID`, `Status`) VALUES
(1, '2024-01-14', 'asdfasdf', 'asdf', 1, 'Sent');

-- --------------------------------------------------------

--
-- Table structure for table `customertb`
--

CREATE TABLE `customertb` (
  `CustomerID` int(11) NOT NULL,
  `CustomerFirstName` varchar(50) DEFAULT NULL,
  `CustomerLastName` varchar(50) DEFAULT NULL,
  `UserName` varchar(100) DEFAULT NULL,
  `Email` varchar(30) DEFAULT NULL,
  `Age` varchar(30) DEFAULT NULL,
  `PhoneNumber` varchar(30) DEFAULT NULL,
  `Password` varchar(30) DEFAULT NULL,
  `Address` varchar(255) DEFAULT NULL,
  `RegisterMonth` varchar(30) DEFAULT NULL,
  `CustomerImage` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `customertb`
--

INSERT INTO `customertb` (`CustomerID`, `CustomerFirstName`, `CustomerLastName`, `UserName`, `Email`, `Age`, `PhoneNumber`, `Password`, `Address`, `RegisterMonth`, `CustomerImage`) VALUES
(1, 'Thi Han', 'Naing', 'thihan', 'ab1@gamil.com', '18', '0987654456', 'Kmd123!@#thihan', 'jasdjkhf', 'December', '../Addimg/659e946ce7716_3dcampaign.jpg'),
(2, 'Tupac', 'Shakur', '2pac', 'shakur69@gmail.com', '25', '098765445645', 'Tupac1233!@#', 'LBC no 789', 'December', '../Addimg/images.jpg'),
(3, 'Kamisato', 'Minato', 'Mina', 'nakama123@gmail.com', '25', '0987645645', 'Kmd1232!@#', '34Road', 'January', '../Addimg/65a0b6b1dfd16_reddit.png'),
(4, 'Kai', 'Ciao', 'Eustass', 'ertr123@gmail.com', '16', '098754245', 'Kmd1232!@#thihhan', '45Avenue', 'January', '../Addimg/name.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `memberstb`
--

CREATE TABLE `memberstb` (
  `MemberID` int(11) NOT NULL,
  `MemberDate` varchar(50) DEFAULT NULL,
  `Description` varchar(255) DEFAULT NULL,
  `Email` varchar(50) DEFAULT NULL,
  `PaymentType` varchar(250) DEFAULT NULL,
  `CustomerID` int(11) DEFAULT NULL,
  `CampaignID` int(11) DEFAULT NULL,
  `MemberStatus` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `socialmediaappstb`
--

CREATE TABLE `socialmediaappstb` (
  `SocialMediaID` int(11) NOT NULL,
  `SocialMediaName` varchar(30) DEFAULT NULL,
  `SocialMediaDescription` varchar(255) DEFAULT NULL,
  `SocialMediaLink` varchar(255) DEFAULT NULL,
  `SocialMediaRating` int(11) DEFAULT NULL,
  `SocialMediaReview` varchar(255) DEFAULT NULL,
  `SocialMediaImage` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `socialmediaappstb`
--

INSERT INTO `socialmediaappstb` (`SocialMediaID`, `SocialMediaName`, `SocialMediaDescription`, `SocialMediaLink`, `SocialMediaRating`, `SocialMediaReview`, `SocialMediaImage`) VALUES
(1, 'Facebook', 'Social Media App ', 'facebook.com', 4, 'One of the popular apps', '../Addimg/6594f2e16ccfa_Facebook.png'),
(2, 'Twitter', 'Twitter also known as X, a famous media used by various type of people mostly Americans', 'twitter.com ', 5, 'Good media for knowledge and info sharing', '../Addimg/65a0b66220c10_twitter.jpg'),
(3, 'Reddit', 'Famous platform for info sharing', 'reddit.com', 4, 'great to share any type of info', '../Addimg/65a0b6b1dfd16_reddit.png'),
(4, 'Linkedin', 'media for job findings', 'linkedin.com', 5, 'Nice media for job findings', '../Addimg/65a0b73a79aaa_linkinden.png'),
(5, 'snapchat', 'media for communications', 'snapchat.com', 4, 'Can find new friends here!', '../Addimg/65a0b795ea816_snapchat.png'),
(6, 'Tiktok', 'Famous social media after 2020s', 'tiktok.com', 3, 'You can share own created videos ', '../Addimg/65a0b7fedd019_tiktok.png'),
(7, 'Instagram', 'Media to share your daily pictures', 'instagram.com', 4, 'Good media to share your daily info with the photos', '../Addimg/65a0b87570d57_instagram.png'),
(8, 'Threads', 'Media like twitter owned by Meta', 'threads.com', 3, 'Not a famous one but good to use', '../Addimg/65a0b8ba2b21a_threads.png');

-- --------------------------------------------------------

--
-- Table structure for table `techniquestb`
--

CREATE TABLE `techniquestb` (
  `TechniqueID` int(11) NOT NULL,
  `TechniqueName` varchar(30) DEFAULT NULL,
  `TechniqueStatus` varchar(255) DEFAULT NULL,
  `TechniqueDescription` varchar(255) DEFAULT NULL,
  `SocialMediaID` int(11) DEFAULT NULL,
  `TechniqueImage1` varchar(255) DEFAULT NULL,
  `TechniqueImage2` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `techniquestb`
--

INSERT INTO `techniquestb` (`TechniqueID`, `TechniqueName`, `TechniqueStatus`, `TechniqueDescription`, `SocialMediaID`, `TechniqueImage1`, `TechniqueImage2`) VALUES
(1, 'End 2 End', 'Latest', 'Safe Technique for messaging', 1, '../Addimg/6594f944e0446_marketing-campaign.jpg', '../Addimg/6594f4ffadf85_download'),
(2, 'Anti-Virus', 'Latest', 'learn to use anti-virus software and advantages of using them', 2, '../Addimg/65a0b58fa6e07_gettyimages-1350595566-q75.jpg', '../Addimg/65a0b58fa74c1_10-Best-Antivirus-in-2020-Windows-Android-iOS-Mac.jpg'),
(3, 'Two-factor authentication', 'Latest', 'resetting the password with ur phone number', 1, '../Addimg/65a0b9bc7969d_2FA-1-1-1-1.png', '../Addimg/65a0b9bc79abe_twofactor-authentication-2fa.asp-final-5dc205d2a08b447abfb2e15eb131e28e.png'),
(4, 'Strong Password Generator', 'Latest', 'this technique suggest you strong passwords ', 3, '../Addimg/65a0bb288827d_unnamed.jpg', '../Addimg/65a0bb28886f3_copy.jpg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `adminstb`
--
ALTER TABLE `adminstb`
  ADD PRIMARY KEY (`AdminID`);

--
-- Indexes for table `campaignstb`
--
ALTER TABLE `campaignstb`
  ADD PRIMARY KEY (`CampaignID`),
  ADD KEY `SocialMediaID` (`SocialMediaID`),
  ADD KEY `CampaignTypeID` (`CampaignTypeID`);

--
-- Indexes for table `campaigntypestb`
--
ALTER TABLE `campaigntypestb`
  ADD PRIMARY KEY (`CampaignTypeID`);

--
-- Indexes for table `contactustb`
--
ALTER TABLE `contactustb`
  ADD PRIMARY KEY (`ContactusID`),
  ADD KEY `CustomerID` (`CustomerID`);

--
-- Indexes for table `customertb`
--
ALTER TABLE `customertb`
  ADD PRIMARY KEY (`CustomerID`);

--
-- Indexes for table `memberstb`
--
ALTER TABLE `memberstb`
  ADD PRIMARY KEY (`MemberID`),
  ADD KEY `CustomerID` (`CustomerID`),
  ADD KEY `CampaignID` (`CampaignID`);

--
-- Indexes for table `socialmediaappstb`
--
ALTER TABLE `socialmediaappstb`
  ADD PRIMARY KEY (`SocialMediaID`);

--
-- Indexes for table `techniquestb`
--
ALTER TABLE `techniquestb`
  ADD PRIMARY KEY (`TechniqueID`),
  ADD KEY `SocialMediaID` (`SocialMediaID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `adminstb`
--
ALTER TABLE `adminstb`
  MODIFY `AdminID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `campaignstb`
--
ALTER TABLE `campaignstb`
  MODIFY `CampaignID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `campaigntypestb`
--
ALTER TABLE `campaigntypestb`
  MODIFY `CampaignTypeID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `contactustb`
--
ALTER TABLE `contactustb`
  MODIFY `ContactusID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `customertb`
--
ALTER TABLE `customertb`
  MODIFY `CustomerID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `memberstb`
--
ALTER TABLE `memberstb`
  MODIFY `MemberID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `socialmediaappstb`
--
ALTER TABLE `socialmediaappstb`
  MODIFY `SocialMediaID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `techniquestb`
--
ALTER TABLE `techniquestb`
  MODIFY `TechniqueID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `campaignstb`
--
ALTER TABLE `campaignstb`
  ADD CONSTRAINT `campaignstb_ibfk_1` FOREIGN KEY (`SocialMediaID`) REFERENCES `socialmediaappstb` (`SocialMediaID`),
  ADD CONSTRAINT `campaignstb_ibfk_2` FOREIGN KEY (`CampaignTypeID`) REFERENCES `campaigntypestb` (`CampaignTypeID`);

--
-- Constraints for table `contactustb`
--
ALTER TABLE `contactustb`
  ADD CONSTRAINT `contactustb_ibfk_1` FOREIGN KEY (`CustomerID`) REFERENCES `customertb` (`CustomerID`);

--
-- Constraints for table `memberstb`
--
ALTER TABLE `memberstb`
  ADD CONSTRAINT `memberstb_ibfk_1` FOREIGN KEY (`CustomerID`) REFERENCES `customertb` (`CustomerID`),
  ADD CONSTRAINT `memberstb_ibfk_2` FOREIGN KEY (`CampaignID`) REFERENCES `campaignstb` (`CampaignID`);

--
-- Constraints for table `techniquestb`
--
ALTER TABLE `techniquestb`
  ADD CONSTRAINT `techniquestb_ibfk_1` FOREIGN KEY (`SocialMediaID`) REFERENCES `socialmediaappstb` (`SocialMediaID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
